@echo off
setlocal
pushd "%~dp0"
if errorlevel 1 goto failed

set "THREADPORT_DATA=%LOCALAPPDATA%\ThreadPortTest"
set "UV_PYTHON_INSTALL_DIR=%THREADPORT_DATA%\python"
set "UV_CACHE_DIR=%THREADPORT_DATA%\cache"
set "U2NET_HOME=%THREADPORT_DATA%\models"
set "THREADPORT_CORE_MODEL=1"
set "THREADPORT_REMBG=0"
set "OMP_NUM_THREADS=2"
set "UV=%CD%\tools\uv.exe"
set "THREADPORT_VENV=%THREADPORT_DATA%\venv"
set "PYTHON=%THREADPORT_VENV%\Scripts\python.exe"

if not exist "%UV%" (
  echo Extract the entire ZIP before running Start ThreadPort.cmd.
  goto failed
)

if not exist "%PYTHON%" (
  echo Setting up ThreadPort's local Python. The first run needs internet access.
  "%UV%" venv --managed-python --python 3.12 "%THREADPORT_VENV%"
  if errorlevel 1 goto failed
)

echo Checking ThreadPort's local packages...
"%UV%" pip sync --python "%PYTHON%" requirements-windows.txt
if errorlevel 1 goto failed

"%PYTHON%" preview.py
if errorlevel 1 goto failed
popd
exit /b 0

:failed
echo.
echo ThreadPort could not start. The reason is shown above.
pause
popd
exit /b 1
