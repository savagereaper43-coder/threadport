"""Run the built site and the ThreadPort API on the same loopback origin."""

import socket
import webbrowser
from pathlib import Path
from threading import Thread
from time import monotonic, sleep
from urllib.error import URLError
from urllib.request import ProxyHandler, build_opener

import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from backend.main import app as api

ROOT = Path(__file__).resolve().parent
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
app.mount("/api", api)
app.mount("/", StaticFiles(directory=ROOT / "web", html=True))


def open_when_ready(base_url: str) -> None:
    opener = build_opener(ProxyHandler({}))
    cutoff = monotonic() + 20
    while monotonic() < cutoff:
        try:
            with opener.open(f"{base_url}/api/health", timeout=1):
                webbrowser.open(f"{base_url}/#auto-bash")
            return
        except (OSError, URLError):
            sleep(0.2)


if __name__ == "__main__":
    with socket.socket() as listener:
        try:
            listener.bind(("127.0.0.1", 8080))
        except OSError:
            listener.bind(("127.0.0.1", 0))
        base_url = f"http://127.0.0.1:{listener.getsockname()[1]}"
        print(f"ThreadPort: {base_url}/#auto-bash", flush=True)
        print("Keep this window open while you test.", flush=True)
        Thread(target=open_when_ready, args=(base_url,), daemon=True).start()
        uvicorn.Server(uvicorn.Config(app, log_level="info")).run(sockets=[listener])
