const s="/assets/black%20shirt%20test-Bc28xYgb.JPG";export{s as f};
